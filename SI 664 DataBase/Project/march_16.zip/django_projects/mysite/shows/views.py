from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from shows.models import Show, Genre
from shows.forms import GenreForm

# Create your views here.


class ShowList(LoginRequiredMixin, View):
    def get(self, request):
        mc = Genre.objects.all().count()
        al = Show.objects.all()

        ctx = {'make_count': mc, 'show_list': al}
        return render(request, 'shows/show_list.html', ctx)


class GenreView(LoginRequiredMixin, View):
    def get(self, request):
        ml = Genre.objects.all()
        ctx = {'genre_list': ml}
        return render(request, 'shows/genre_list.html', ctx)


# We use reverse_lazy() because we are in "constructor attribute" code
# that is run before urls.py is completely loaded
class GenreCreate(LoginRequiredMixin, View):
    template = 'shows/genre_form.html'
    success_url = reverse_lazy('shows:all')

    def get(self, request):
        form = GenreForm()
        ctx = {'form': form}
        return render(request, self.template, ctx)

    def post(self, request):
        form = GenreForm(request.POST)
        if not form.is_valid():
            ctx = {'form': form}
            return render(request, self.template, ctx)

        genre = form.save()
        return redirect(self.success_url)


# MakeUpdate has code to implement the get/post/validate/store flow
# AutoUpdate (below) is doing the same thing with no code
# and no form by extending UpdateView
class GenreUpdate(LoginRequiredMixin, View):
    model = Genre
    success_url = reverse_lazy('shows:all')
    template = 'shows/genre_form.html'

    def get(self, request, pk):
        genre = get_object_or_404(self.model, pk=pk)
        form = GenreForm(instance=genre)
        ctx = {'form': form}
        return render(request, self.template, ctx)

    def post(self, request, pk):
        genre = get_object_or_404(self.model, pk=pk)
        form = GenreForm(request.POST, instance=genre)
        if not form.is_valid():
            ctx = {'form': form}
            return render(request, self.template, ctx)

        form.save()
        return redirect(self.success_url)


class GenreDelete(LoginRequiredMixin, View):
    model = Genre
    success_url = reverse_lazy('shows:all')
    template = 'shows/genre_confirm_delete.html'

    def get(self, request, pk):
        genre = get_object_or_404(self.model, pk=pk)
        form = GenreForm(instance=genre)
        ctx = {'genre': genre}
        return render(request, self.template, ctx)

    def post(self, request, pk):
        genre = get_object_or_404(self.model, pk=pk)
        genre.delete()
        return redirect(self.success_url)


# Take the easy way out on the main table
# These views do not need a form because CreateView, etc.
# Build a form object dynamically based on the fields
# value in the constructor attributes
class ShowCreate(LoginRequiredMixin, CreateView):
    model = Show
    fields = '__all__'
    success_url = reverse_lazy('shows:all')


class ShowUpdate(LoginRequiredMixin, UpdateView):
    model = Show
    fields = '__all__'
    success_url = reverse_lazy('shows:all')


class ShowDelete(LoginRequiredMixin, DeleteView):
    model = Show
    fields = '__all__'
    success_url = reverse_lazy('shows:all')

# We use reverse_lazy rather than reverse in the class attributes
# because views.py is loaded by urls.py and in urls.py as_view() causes
# the constructor for the view class to run before urls.py has been
# completely loaded and urlpatterns has been processed.

# References

# https://docs.djangoproject.com/en/3.0/ref/class-based-views/generic-editing/#createview
