from django.contrib import admin

from shows.models import Show, Genre

# Register your models here.

admin.site.register(Show)
admin.site.register(Genre)