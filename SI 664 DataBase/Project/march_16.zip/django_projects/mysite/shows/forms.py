from django.forms import ModelForm
from shows.models import Genre


# Create the form class.
class GenreForm(ModelForm):
    class Meta:
        model = Genre
        fields = '__all__'