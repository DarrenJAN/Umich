from django.apps import AppConfig


class GviewConfig(AppConfig):
    name = 'gview'
