from django.apps import AppConfig


class FavsqlConfig(AppConfig):
    name = 'favsql'
