This is a derivative of the owner example code

