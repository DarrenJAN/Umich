from django.apps import AppConfig


class ViewsConfig(AppConfig):
    name = 'views'
