from django.apps import AppConfig


class ManyConfig(AppConfig):
    name = 'many'
