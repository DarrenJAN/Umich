from django.apps import AppConfig


class AuthzConfig(AppConfig):
    name = 'authz'
