from django.apps import AppConfig


class TagmeConfig(AppConfig):
    name = 'tagme'
