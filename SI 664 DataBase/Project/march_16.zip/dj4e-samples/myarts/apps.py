from django.apps import AppConfig


class MyartsConfig(AppConfig):
    name = 'myarts'
