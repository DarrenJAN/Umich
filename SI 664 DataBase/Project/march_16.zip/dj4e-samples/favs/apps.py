from django.apps import AppConfig


class FavsConfig(AppConfig):
    name = 'favs'
