

https://github.com/bernardopires/django-tenant-schemas

https://readthedocs.org/projects/building-multi-tenant-applications-with-django/downloads/pdf/latest/

