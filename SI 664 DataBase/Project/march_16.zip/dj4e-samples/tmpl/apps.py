from django.apps import AppConfig


class TmplConfig(AppConfig):
    name = 'tmpl'
