Copyright Raj Rao Nadakuditi 2020

Please remember that this content (including the content of the codex that these
files were taken from) is copyrighted. Do not distribute these files, or upload
to a public place, as you agreed when registering for a user account on Mynerva.

# How to get started

Follow the instructions below to get your programming language environment setup
and install all of the packages that the codex depends on.

Note that the code from the codex is not included in this archive. You should
copy-and-paste the relevant bits from the codex as necessary.

## Python

### Google Colaboratory (recommended)

Google Colaboratory (Colab) is a web-based Jupyter notebook environment. Using
Colab is recommended for easy exploration (and it doesn't require any
installation, e.g., for school-owned computers).

Instructions for how to use Colab with this workspace export can be found at
https://colab.research.google.com/drive/1MJ2kfPzQUlWffny2q3r-xGvleGiZmVI4?usp=sharing.

### Local Python installation

You can install Python on your personal computer (this usually requires admin
access to the computer you're installing on). See the official
[Downloading Python guide](https://wiki.python.org/moin/BeginnersGuide/Download)
for instructions.

## Julia

1. Download the latest version of Julia from https://julialang.org/downloads/.
   - You may want to download the version of Julia used in the course instead;
     you can figure this out by running `versioninfo()` in the scratchpad.
   - For Windows, you most likely should choose the _64-bit (installer)_ option.
2. Install Julia (exact steps depend on your operating system).
   - If you have questions, Google is a great place to start. You can also post
     on the [JuliaLang Discourse Forum](https://discourse.julialang.org/) if you
     need additional help.
3. Open Julia. You can usually do this from the start menu (on Windows) or
   navigating to your _Applications_ folder (on Mac OS). It should open up in a
   terminal window.
4. In the Julia terminal, navigate to this directory (wherever you extracted the
   archive to).
   ```julia
   # For example...
   cd("Downloads/Introduction to Matrix Math")
   ```
5. Activate the Julia project. This will install all of the relevant packages
   (at the correct versions to ensure reproducibility). **IMPORTANT: If using
   Jupyter, you must do this in a terminal outside of Jupyter before opening a
   notebook.**
   ```julia
   using Pkg
   Pkg.activate(".")
   Pkg.instantiate()
   ```
6. Run your code as normal.

### Using Jupyter

To use Jupyter notebooks, the easiest way is to install from within Julia.

To install IJulia, run these commands (you only need to do this once):

```julia
using Pkg
Pkg.add("IJulia")
Pkg.build("IJulia")
```

To launch Jupyter, run these commands in the Julia session:

```julia
using IJulia
IJulia.notebook()
```

You might be prompted to download the notebook software. Enter `Y` to allow
this. The notebook interface should open in a browser window (if it doesn't,
there should be a link in the terminal output).

### Installing WebIO

WebIO is required to using the `@manipulate` widgets from Interact.jl, as well
as a few other interactive widgets in the codices.

```julia
using Pkg
Pkg.add("WebIO")
using WebIO
WebIO.install_jupyter_nbextension()
```
