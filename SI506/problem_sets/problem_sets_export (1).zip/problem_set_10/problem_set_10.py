
def main():
    # Problem 1.0
    planet_data = None

if __name__ == '__main__':
    main()
