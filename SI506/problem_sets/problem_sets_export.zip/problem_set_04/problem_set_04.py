musicians = [['name', 'city', 'state', 'instruments', 'inspiration', 'birth_date', 'death_date'],
    [' Christian Scott Atunde Adjuah ', 'New Orleans', 'LA', ['trumpet'], 'Miles Davis', 'Mar 1983'],
    ['Ron Carter ', 'Ferndale', 'mi', ['double bass', 'cello'], 'Miles Davis', 'May 4, 1937'],
    [' Alice Coltrane ', 'Detroit', 'MI', ['piano', 'harp', 'vocals'], 'Ernest Farrow', '1937', '2007'],
    ['Esperanza Spalding', 'Portland', 'OR', ['double bass', 'guitar', 'vocals'], 'Ron Carter', '1984'],
    [' Robert Glasper ', 'Houston', 'tx', ['piano'], 'Herbie Hancock', 'April 1978'],
    [' Marquis Hill ', 'Chicago', 'IL', ['trumpet'], 'Lee Morgan', 'April 15, 1987'],
    [' Dorothy Ashby', 'Detroit', 'Mi', ['harp', 'piano', 'koto'], 'Omar Khayyam', 'Aug 1932', '1986'],
    ['Walter Smith III ', 'Houston', 'Tx', ['saxophone'], 'John Coltrane', 'Sept 24, 1980'],
    [' Cecile McLorin Salvant', 'Miami', 'fL', ['vocals'], 'Sarah Vaughan','August 28, 1989'],
    [' Sarah Elizabeth Charles', 'Springfield', 'MA', ['vocals'], 'Sarah Vaughan', '1989'],
    ['Miles Davis', 'Alton', 'iL', ['trumpet', 'cornet', 'piano'], 'Elwood Buchanan','1926', '1991'],
    ['John Coltrane', 'Hamlet', 'Nc', ['saxophone'], 'Alice Coltrane', 'Sep 1926', 'July 17, 1967'],
    ['Herbie Hancock', 'Chicago', 'il', ['piano', 'keyboard'], 'Miles Davis', '1940'],
    ['Roy Brooks ', 'Detroit', 'MI', ['drums'], 'Lionel Hampton','March 9, 1938', '2005'],
    ['Wayne Shorter', 'Newark', 'nj', ['saxophone'], 'John Coltrane', 'Aug 25, 1933'],
    [' Bobbi Humphrey', 'Marlin', 'TX', ['flute', 'vocals'], 'Herbie Mann', '1950'],
    [' Thelonius Monk', 'Rocky Mount', 'NC', ['piano'], 'Duke Ellington', '1917', 'February 17, 1982']
]

# PROBLEM 1 (16 POINTS)
def clean_list(info):
    pass

print(f'\nProblem 1: musicians =\n{musicians}')


# PROBLEM 2 (16 POINTS)
def get_state(info):
    pass

mi_musicians = None

print(f'\nProblem 2: mi_musicians =\n{mi_musicians}')


# PROBLEM 3 (16 POINTS)
south_states = ['al', 'ar', 'de', 'fl', 'ga', 'ky', 'la', 'md', 'ms',
    'nc', 'ok', 'sc', 'tn', 'tx', 'va', 'wv']

northeast_states = ['ct', 'ma', 'me', 'nh', 'nj', 'ny', 'pa', 'ri', 'vt']


# PROBLEM 4 (16 POINTS)


# PROBLEM 5 (16 POINTS)


# PROBLEM 6 (20 POINTS)


# PROBLEM 7 (25 POINTS)
def plays_woodwind():
    woodwinds = ['clarinet', 'trumpet', 'saxophone', 'flute', 'bassoon',
        'oboe', 'trumpet', 'piccolo', 'cornet']