# START LAB EXERCISE 01
print('Lab Exercise 01 \n')

# PROBLEM 1 (2 points)
north_quad = "North Quad"
ccrb = "Central Campus Recreation Building"
kelsey_museum = "Kelsey Museum of Archaeology"
mason_hall = "Mason Hall"

locations = None


# PROBLEM 2 (2 points)
num_locations = None


# PROBLEM 3 (2 points points)
north_quad_study_areas = 30
ccrb_study_areas = 0
kelsey_museum_study_areas = 9
mason_hall_study_areas = 22

total_study_areas = None


# PROBLEM 4 (2 points)
avg_study_areas = None


# PROBLEM 5 (4 points)
study_areas = 'Central Campus Recreation Building; 0, Kelsey Museum of Archeology; 9, Mason Hall; 22, North Quad; 30'
fixed_locations = None


# PROBLEM 6 (4 points)
study_area_locations = None


# PROBLEM 7 (2 points)
statement = None


# PROBLEM 8 (2 points)
two_smallest_buildings = None


# END LAB EXERCISE
