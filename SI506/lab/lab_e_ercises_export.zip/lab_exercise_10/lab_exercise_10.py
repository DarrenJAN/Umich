# LAB EXERCISE 10

print('Lab Exercise 10\n')

# SETUP CODE

hero_homeworlds = {
    'luke': 'tatooine',
    'leia': 'alderaan',
    'chewbacca': 'kashyyyk',
    'han solo': 'corellia',
    'lando calrissian': 'socorro'
}

planet_filters = ('name', 'diameter', 'climate', 'terrain', 'population')

# END SETUP

# PROBLEM 3 (5 points)
def create_planet(planet, filters):
    """Loops over < planet >, then loops over < filters >. For each key in
    < planet > that exists in < filters >, converts data and assigns converted
    value to the same key in < new_planet > dictionary. If data is numeric,
    converts to type < int >. For data in the 'climate' and 'terrain' keys,
    splits data.

    Parameters:
        planet (dict): A SWAPI representation of a planet.
        filters (tuple): A tuple containing the names of the planet features.

    Returns:
        new_planet (dict): A dictionary containing filtered, converted planet data.
    """

    pass

# Call functions below
def main():
    """
    This function serves as the point of entry and controls the flow of this Python script

    Parameters:
        None

    Returns:
        None
    """

    # Problem 02 (4 points)
    print("\nProblem 02:\n")

    # Problem 03 (5 points)
    print("\nProblem 03:\n")

    # Problem 04 (4 points)
    print("\nProblem 04:\n")

    # Problem 05 (3 points)
    print("\nProblem 05:\n")

if __name__ == "__main__":
    main()
