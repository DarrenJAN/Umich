import sw_utils as utl


def assign_crew_members(starship, crew_positions, personnel):
    """Maps crew members by position to the passed in < starship > 'crew_members'
    key. Both the < crew_positions > and < personnel > lists should contain the same number
    of elements. The individual < crew_positions > and < personnel > elements are then paired
    by index position and stored in a dictionary structured as follows:

    {< crew_position[0] >: < personnel[0] >, < crew_position[1] >: < personnel[1] >, ...}

    The crew members dictionary is mapped (i.e., assigned) to the passed in
    starship's 'crew_members' key and the crewed starship is returned to the caller.

    WARN: The number of crew members that can be assigned to the passed in < starship > is
    limited by the starship's "crew_size" value. No additional crew members are permitted
    to be assigned to the < starship >.

    WARN: A single line dictionary comprehension that assigns a new dictionary to the passed in
    < starship >'s "crew_members" key must be written in order to earn full credit. Utilize the
    parameter names in the dictionary comprehension (DO NOT assign the passed in dictionary
    and lists to local variables and then reference them in the comprehension).

        Parameters:
            starship (dict): Representation of a starship
            crew_positions (list): crew positions (e.g., 'pilot', 'copilot', etc.)
            personnel (list): persons to be assigned to the crew positions

        Returns:
            dict: starship with assigned crew members
    """

    pass # TODO Implement


def board_passengers(starship, passengers):
    """Assigns < passengers > to the passed in < starship > but limits boarding to less than
    or equal to the starship's "max_passengers" value. The passengers list (in whole or in part)
    is then mapped (i.e., assigned) to the passed in starship's 'passengers_on_board' key. After
    boarding the passengers the starship is returned to the caller.

    WARN: The number of passengers permitted to board a starship is limited by the starship's
    "max_passengers" value. If the number of passengers attempting to board exceeds the starship's
    "max_passengers" value only the first n passengers (where `n` = "max_passengers") are
    permitted to board the vessel.

        Parameters:
            starship (dict): Representation of a starship
            passengers (list): passengers to transport aboard starship

        Returns:
            dict: starship with assigned passengers
    """

    pass # TODO Implement


def calculate_articles_mean_word_count(articles):
    """Calculates the mean (e.g., average) word count of the passed in list of < articles >.
    Excludes from the calculation any article with a word count of zero (0). Word counts
    are summed and then divided by the number of non-zero word count articles. The resulting mean
    value is rounded to the second (2nd) decimal place and returned to the caller.

    WARN: Add a local variable to hold a count of the number of articles with a word count of
    zero (0). Then subtract the zero word count from the total number of passed in articles in
    order to ensure that the divisor reflects the actual number of articles upon which to
    compute the mean.

    Parameters:
        articles (list): nested dictionary representations of New York Times articles

    Returns:
        float: mean word count rounded to the second (2nd) decimal place
    """

    pass # TODO Implement


def convert_episode_values(episodes):
    """Converts select string values to either int, float, list, or None in the passed in list of
    nested dictionaries. The function delegates to the < utl.convert_to_* > functions the task of
    converting the specified strings to either int, float, or list (or None if utl.convert_to_none
    is eventually called).

    Conversions:
        str to int: 'series_season_num', 'series_episode_num', 'season_episode_num'
        str to float: 'episode_prod_code', 'episode_us_viewers_mm'
        str to list: 'episode_writers'

    Parameters:
        episodes (list): nested episode dictionaries

    Returns:
        list: nested episode dictionaries containing mutated key-value pairs
    """

    pass # TODO Implement


def count_episodes_by_director(episodes):
    """Constructs and returns a dictionary of key-value pairs that associate each director with a
    count of the episodes that they directed. The director's name comprises the key and the
    associated value a count of the number of episodes they directed. Duplicate keys are NOT
    permitted.

    Format:
        {
            < director_name_01 >: < episode_count >,
            < director_name_02 >: < episode_count >,
            ...
        }

    Parameters:
        episodes (list): nested episode dictionaries

    Returns:
        dict: a dictionary that store counts of the number of episodes directed
              by each director
    """

    pass # TODO Implement


def create_droid(data):
    """Returns a new dictionary representation of a droid from the passed in < data >,
    converting string values to the appropriate type whenever possible.

    Type conversions:
        height -> height_cm (str to float)
        mass -> mass_kg (str to float)
        equipment -> equipment (str to list)

    Key order:
        url
        name
        model
        manufacturer
        create_year
        height_cm
        mass_kg
        equipment
        instructions

    Parameters:
        data (dict): source data

    Returns:
        dict: new dictionary
    """

    pass # TODO Implement


def create_person(data, planets=None):
    """Returns a new dictionary representation of a person from the passed in < data >,
    converting string values to the appropriate type whenever possible.

    Both the person's "homeworld" and "species" values are used to retrieve SWAPI dictionary
    representations of the planet and specie values. Retrieving the SWAPI homeworld and
    species data is delegated to the function < utl.get_resource >.

    If an optional Wookieepedia-sourced < planets > list is provided, the task of retrieving
    the appropriate nested dictionary (filters on the passed in homeworld planet
    name) is delegated to the function < get_wookieepedia_data >.

    Before the homeworld and species data is mapped (e.g. assigned) to the person's "homeworld"
    and "species" keys, the functions < create_planet > and < create_species > are called
    in order to provide new dictionary representations of the person's homeworld and species.

    Type conversions:
        height -> height_cm (str to float)
        mass -> mass_kg (str to float)
        homeworld -> homeworld (str to dict)
        species -> species (str to dict)

    Key order:
        url
        name
        birth_year
        height_cm
        mass_kg
        homeworld
        species
        force_sensitive

    Parameters:
        data (dict): source data
        planets (list): optional supplemental planetary data

    Returns:
        dict: new dictionary
    """

    pass # TODO Implement


def create_planet(data):
    """Returns a new dictionary representation of a planet from the passed in < data >,
    converting string values to the appropriate type whenever possible.

    Type conversions:
        suns -> suns (str->int)
        moon -> moons (str->int)
        orbital_period -> orbital_period_days (str to float)
        diameter -> diameter_km (str to int)
        gravity -> gravity_std (str to float)
        climate -> climate (str to list)
        terrain -> terrain (str to list)
        population -> population (str->int)

    Key order:
        url
        name
        region
        sector
        suns
        moons
        orbital_period_days
        diameter_km
        gravity_std
        climate
        terrain
        population

    Parameters:
        data (dict): source data

    Returns:
        dict: new dictionary
    """

    pass # TODO Implement


def create_species(data):
    """Returns a new dictionary representation of a species from the passed in
    < data >, converting string values to the appropriate type whenever possible.

    Type conversions:
        average_lifespan -> average_lifespan (str to int)
        average_height -> average_height_cm (str to float)

    Key order:
        url
        name
        classification
        designation
        average_lifespan
        average_height_cm
        language

    Parameters:
        data (dict): source data

    Returns:
        dict: new dictionary
    """

    pass # TODO Implement


def create_starship(data):
    """Returns a new starship dictionary from the passed in < data >, converting string
    values to the appropriate type whenever possible.

    Assigning crews and passengers consitute separate
    operations.

    Type conversions:
        length -> length_m (str to float)
        max_atmosphering_speed -> max_atmosphering_speed (str to int)
        hyperdrive_rating -> hyperdrive_rating (str to float)
        MGLT -> MGLT (str to int)
        crew -> crew_size (str to int)
        passengers -> max_passengers (str to int)
        armament -> armament (str to list)
        cargo_capacity -> cargo_capacity_kg (str to int)

    Key order:
        url
        name
        model
        starship_class
        manufacturer
        length_m
        max_atmosphering_speed
        hyperdrive_rating
        top_speed_mglt
        armament
        crew_size
        crew_members
        max_passengers
        passengers_on_board
        cargo_capacity_kg
        consumables

    Parameters:
        data (dict): source data

    Returns:
        dict: new dictionary
    """

    pass # TODO Implement


def get_wookieepedia_data(wookiee_data, filter):
    """Attempts to retrieve a Wookieepedia sourced dictionary representation of a
    Star Wars entity (e.g., droid, person, planet, species, starship, or vehicle)
    from the < wookiee_data > list using the passed in filter value. The function performs
    a case-insensitive comparison of each nested dictionary's "name" value against the
    passed in < filter > value. If a match is obtained the dictionary is returned to the
    caller; otherwise None is returned.

    Parameters:
        wookiee_data (list): Wookieepedia-sourced data stored in a list of nested dictionaries
        filter (str): name value used to match on a dictionary's "name" value

    Returns
        dict|None: Wookieepedia-sourced data dictionary if match on the filter is obtained;
                   otherwise returns None
    """

    pass # TODO Implement


def get_most_viewed_episode(episodes):
    """Identifies and returns a list of one or more episodes with the highest recorded
    viewership. Ignores episodes with no viewship value. Includes in the list only those
    episodes that tie for the highest recorded viewership. If no ties exist only one
    episode will be returned in the list. Delegates to the function < has_viewer_data >
    the task of determining if the episode includes viewership "episode_us_viewers_mm"
    numeric data.

    Parameters:
        episodes (list): nested episode dictionaries

    Returns:
        list: episode(s) with the highest recorded viewership.
    """

    pass # TODO Implement


def get_nyt_news_desks(articles):
    """Returns a list of New York Times news desks sourced from the passed in < articles >
    list. Accesses the news desk name from each article's "news_desk" key-value pair. Filters
    out duplicates in order to guarantee uniqueness.

    Delegates to the function < utl.convert_to_none > the task of converting "news_desk"
    values that equal "None" (a string) to None. Only news_desk values that are "truthy"
    (i.e., not None) are returned in the list.

    Parameters:
        articles (list): nested dictionary representations of New York Times articles

    Returns:
        list: news desk strings (no duplicates)
    """

    pass # TODO Implement


def group_nyt_articles_by_news_desk(news_desks, articles):
    """Returns a dictionary of "news desk" key-value pairs that group the passed in
    < articles > by their parent news desk. The passed in < news_desks > list provides
    the keys while each news desk's < articles > are stored in a list and assigned to
    the appropriate "news desk" key. Each key-value pair is structured as follows:

    {
        < news_desk_name_01 >: [{< article_01 >}, {< article_05 >}, ...],
        < news_desk_name_02 >: [{< article_20 >}, {< article_31 >}, ...],
        ...
    }

    Each dictionary that represents an article is a "thinned" version of the New York Times
    original and consists of the following key-value pairs ordered as follows:

    Key order:
        web_url
        headline_main (new name)
        news_desk
        byline_original (new name)
        document_type
        material_type (new name)
        abstract
        word_count
        pub_date

    Parameters:
        news_desks (list): list of news_desk names
        articles (list): nested dictionary representations of New York Times articles

    Returns
        dict: key-value pairs that group articles by their parent news desk
    """

    pass # TODO Implement


def has_viewer_data(episode):
    """Checks the truth value of an episode's "episode_us_viewers_mm" key-value pair. Returns
    True if the truth value is "truthy" (e.g., numeric values that are not 0, non-empty sequences
    or dictionaries, boolean True); otherwise returns False if a "falsy" value is detected (e.g.,
    empty sequences (including empty or blank strings), 0, 0.0, None, boolean False)).

    Parameters:
        episode (dict): represents an episode

    Returns:
        bool: True if "episode_us_viewers_mm" value is truthy; otherwise False
    """

    pass # TODO Implement

def main():
    """Entry point for program.

    Parameters:
        None

    Returns:
        None
    """

    # 9.1 CHALLENGE 01

    # TODO Refactor utl.read_csv()

    clone_wars = None

    clone_wars_22 = None
    clone_wars_2012 = None
    clone_wars_url = None
    clone_wars_even_num_seasons = None


    # 9.2 Challenge 02

    # TODO Implement convert_to_none(), convert_to_int(), convert_to_float(), convert_to_list()


    # 9.3 CHALLENGE 03

    # TODO Refactor utl.read_csv_to_dicts()

    clone_wars_episodes = None

    # TODO Implement has_viewer_data()

    # TODO Implement loop


    # 9.4 Challenge 04

    # TODO Implement convert_episode_values()

    clone_wars_episodes = None


    # 9.5 Challenge 05

    # TODO Implemennt get_most_viewed_episode()

    most_viewed_episode = None


    # 9.6 Challenge 06

    # TODO Implement count_episodes_by_director()

    director_episode_counts = None


    # 9.7 CHALLENGE 07

    articles = None

    # TODO Implement get_nyt_news_desks()

    news_desks = None


    # 9.8 CHALLENGE 08

    # TODO Implement group_nyt_articles_by_news_desk()

    news_desk_articles = None


    # 9.9 CHALLENGE 09

    # TODO Implement calculate_articles_mean_word_count()

    ignore = ('Business Day', 'Movies')

    # TODO Implement loop


    # 9.10 CHALLENGE 10

    # TODO Implement convert_gravity_value()


    # 9.11 CHALLENGE 11

    # TODO Implement get_wookieepedia_data()

    wookiee_planets = None

    wookiee_dagobah = None
    wookiee_haruun_kal = None


    # 9.12 CHALLENGE 12

    # TODO Implement create_planet()

    swapi_tatooine = None
    wookiee_tatooine = None

    tatooine = None


    # 9.13 CHALLENGE 13

    # TODO Implement create_droid()

    wookiee_droids = None

    swapi_r2_d2 = None
    wookiee_r2_d2 = None

    r2_d2 = None


    # 9.14 Challenge 14

    # TODO Implement create_species()

    swapi_human_species = None

    human_species = None


    # 9.15 Challenge 15

    # TODO Implement create_person()

    # 9.15.2
    wookiee_people = None

    swapi_anakin = None
    wookiee_anakin = None

    anakin = None


    # 9.16 CHALLENGE 16

    # TODO Implement create_starship()

    wookiee_starships = None

    wookiee_twilight = None

    twilight = None


    # 9.17 CHALLENGE 17

    # TODO Implement board_passengers()

    swapi_padme = None
    wookiee_padme = None

    padme = None

    swapi_c_3po = None
    wookiee_c_3po = None

    c_3po = None

    # TODO Get passengers aboard the starship Twilight


    # 9.18 CHALLENGE 18

    # TODO Implement assign_crew_members()

    swapi_obi_wan = None
    wookiee_obi_wan = None

    obi_wan = None

    # TODO Assign crew members to the starship Twilight

    # TODO Add r2_d2 instructions


    # 10.0 ESCAPE

    # TODO Add r2_d2 instruction (2nd order)

    # TODO Escape from the Malevolence (write to file)


    # PERSIST CACHE (DO NOT COMMENT OUT)
    utl.write_json(utl.CACHE_FILEPATH, utl.cache)


if __name__ == '__main__':
    main()
